plugins { id("com.android.application") }
android { namespace = "bd.gov.oep.employee"; compileSdk = 35
 defaultConfig { applicationId = "com.oep.employee.webapp"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" } }
