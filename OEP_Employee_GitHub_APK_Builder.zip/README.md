# OEP Employee Android WebView (unofficial)

Website: https://employee.oep.gov.bd/

This is an independent WebView wrapper, not an official OEP/government app. It requires internet access. Some website functions (especially camera capture, authenticated/POST/blob downloads, popups) may require additional development and device testing.

## Build an APK on GitHub (no Android Studio required)

1. Create a new GitHub repository (private recommended) with the default branch `main`.
2. Extract this ZIP. Upload **all files and folders at the root**, including the hidden `.github` folder, to the repository (GitHub's Add file > Upload files or git push).
3. Go to the repository's **Actions** tab and enable workflows if prompted.
4. Select **Build Android APK** > **Run workflow** (or push to `main`).
5. Wait for the workflow to finish, open its run, and download **OEP-Employee-APK** under **Artifacts**.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android device.

The debug APK is automatically signed with a debug key, suitable for personal testing, not Play Store publishing. APK is not included in this project ZIP. Requires GitHub Actions and access to Google Maven/Android SDK downloads. Build has not been verified in GitHub Actions.

Package: `com.oep.employee.webapp`. Min Android version: 7.0 (API 24).
